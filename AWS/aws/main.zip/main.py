def lamda_handler (event, context):
    return 'hello from aws lamda using terraform'